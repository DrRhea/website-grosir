<footer class="bg-white">
  <div class="mx-auto max-w-7xl px-6 py-12 md:flex md:items-center md:justify-between lg:px-8">
    <div class="mt-8 md:order-1 md:mt-0">
      <p class="text-center text-xs leading-5 text-gray-500">&#169; 2024 Agen Telur. Semua hak cipta dilindungi.
      </p>
    </div>
  </div>
</footer><?php /**PATH C:\Users\Arya Jagadditha\Documents\01_Projects\Work\grosir\resources\views/components/grosir/footer.blade.php ENDPATH**/ ?>