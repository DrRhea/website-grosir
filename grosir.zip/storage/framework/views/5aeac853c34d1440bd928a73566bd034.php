<!doctype html>
<html lang="en" class="h-full bg-gray-50">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Wishlist Grosir</title>

  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="h-full">
<div class="overflow-hidden">
  <div class="bg-white">
    <?php echo $__env->make('components.grosir.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="relative isolate pt-14">
      <div class="bg-white">
        <div class="max-w-2xl px-4 py-8 mx-auto sm:px-6 lg:max-w-7xl lg:px-8">
          <h2 class="text-2xl font-semibold text-gray-900 mb-8">Produk Favorit Anda</h2>
          <div class="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">
            <?php $__empty_1 = true; $__currentLoopData = $wishlistsWithProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <a href="/grosir/produk/detail/<?php echo e(Str::slug($item['product']->nama_produk)); ?>" class="group">
                <div class="relative w-full overflow-hidden bg-gray-200 rounded-lg aspect-h-1 aspect-w-1 xl:aspect-h-8 xl:aspect-w-7">
                  <img src="<?php echo e(asset($item['product']->foto_produk)); ?>" alt="<?php echo e($item['product']->nama_produk); ?>" class="object-cover object-center w-full h-[300px] group-hover:opacity-75">
                  <button type="button" class="absolute p-2 bg-white rounded-full shadow-md top-2 right-2 hover:bg-gray-100" onclick="document.getElementById('wishlist-form-remove-<?php echo e($item['wishlist']->id); ?>').submit();">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                      <path d="M20.205 4.791a5.938 5.938 0 0 0-4.209-1.754A5.906 5.906 0 0 0 12 4.595a5.904 5.904 0 0 0-3.996-1.558 5.942 5.942 0 0 0-4.213 1.758c-2.353 2.363-2.352 6.059.002 8.412L12 21.414l8.207-8.207c2.354-2.353 2.355-6.049-.002-8.416z"></path>
                    </svg>
                  </button>
                  <form id="wishlist-form-remove-<?php echo e($item['wishlist']->id); ?>" method="POST" action="<?php echo e(route('grosir.produk.wishlist.remove')); ?>" style="display: none;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <input type="hidden" name="id_produk" value="<?php echo e($item['wishlist']->id_produk); ?>">
                  </form>
                </div>
                <h3 class="mt-4 text-sm text-gray-700"><?php echo e(ucwords($item['product']->nama_produk)); ?></h3>
                <p class="mt-1 text-lg font-medium text-gray-900">Rp<?php echo e(number_format($item['product']->harga_produk, 0, ',', '.')); ?>

                  <span class="select-none text-sm text-gray-400">/ Butir</span></p>
              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <p class="text-gray-500">Wishlist Anda kosong.</p>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('components.grosir.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\Arya Jagadditha\Documents\01_Projects\Work\grosir\resources\views/grosir/wishlist.blade.php ENDPATH**/ ?>