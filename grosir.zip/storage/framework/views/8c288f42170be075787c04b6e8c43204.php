<!doctype html>
<html lang="en" class="h-full bg-gray-50">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Aplikasi Grosir</title>

  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="h-full">

<div class="overflow-hidden">
  <div class="bg-white">
    <?php echo $__env->make('components.grosir.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="relative isolate pt-14">
      <div class="">

        <div x-data="{ open: false }" @keydown.window.escape="open = false">
          <!-- Mobile filter dialog -->

          <main>
            <div class="bg-white">
              <div class="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
                <h1 class="text-3xl font-bold tracking-tight text-gray-900">Produk Kami</h1>
                <p class="mt-4 max-w-xl text-sm text-gray-700">Our thoughtfully designed workspace objects are crafted in limited runs. Improve your productivity and organization with these sale items before we run out.</p>
              </div>
            </div>

            <!-- Product grid -->
            <section aria-labelledby="products-heading" class="mx-auto max-w-2xl px-4 pb-16 pt-12 sm:px-6 sm:pb-24 sm:pt-16 lg:max-w-7xl lg:px-8">
              <h2 id="products-heading" class="sr-only">Products</h2>

              <div class="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">
                <a href="#" class="group">
                  <div class="aspect-h-1 aspect-w-1 w-full overflow-hidden rounded-lg bg-gray-200 xl:aspect-h-8 xl:aspect-w-7">
                    <img src="https://tailwindui.com/img/ecommerce-images/category-page-04-image-card-01.jpg" alt="Tall slender porcelain bottle with natural clay textured body and cork stopper." class="h-full w-full object-cover object-center group-hover:opacity-75">
                  </div>
                  <h3 class="mt-4 text-sm text-gray-700">Earthen Bottle</h3>
                  <p class="mt-1 text-lg font-medium text-gray-900">$48</p>
                </a>

              </div>
            </section>
          </main>

        </div>
      </div>
    </div>

  </div>
</div>

<?php echo $__env->make('components.grosir.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\Arya Jagadditha\Documents\01_Projects\Work\grosir\resources\views/grosir/produk.blade.php ENDPATH**/ ?>