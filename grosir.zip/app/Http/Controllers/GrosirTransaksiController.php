<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GrosirTransaksiController extends Controller
{
    //

  public function store(Request $request) {
    dd($request->all());
  }
}
